//
// Created by Ruchit Vithani on 10/1/22.
//

#ifndef HOMEWORK_3_UNITTEST_H
#define HOMEWORK_3_UNITTEST_H


class UnitTest {
public:
    static bool test_Binomial_Pricer();
    static bool test_BSM_Pricer();

};


#endif //HOMEWORK_3_UNITTEST_H
